The mazes used for this project can be found in ../rl_sim_fork/mazes

Small Maze 1_smallest2.maze

Large Maze 8_big.maze

To run, navigate to ../rl_sim_fork/src and compile/run MainUI.java

This is predominantly the code of http://www.cs.cmu.edu/~awm/rlsim/ with image functionality added by https://github.com/theJenix/rl_sim_fork

I only made minor adjustments to help also see the runtime of Q-Learning in the console log.